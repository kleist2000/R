### 1
index <- grep("^car$|^cars$", TEXTS)
head(index)
span <- vector()
for (i in index)
{
span <- c(span, (i-8):(i+8))
}
span <- span[span>0&span<=length(TEXTS)]
cooccurrence <- TEXTS[span]
cooccurrence[1:10]


# 2
Freq.span <- sort(table(cooccurrence), 
           decreasing=T)
Freq.co <- data.frame(W1=vector(),
           W2=vector(), W1W2=vector(),
           N =vector())
n <- 1
for (i in (1:length(Freq.span)))
{
Freq.co[n,] <- c(length(TEXTS[TEXTS=="car"|TEXTS=="cars"]),
  length(TEXTS[TEXTS==names(Freq.span)[i]]),
  Freq.span[i], length(TEXTS))
rownames(Freq.co)[n] <- names(Freq.span)[i]
n <- n + 1                 
}
head(Freq.span)
head(names(Freq.span))
head(Freq.co)


# 3
collocates <- data.frame(Freq.co,
   t.score=(Freq.co$W1W2 - 
            ((Freq.co$W1*Freq.co$W2)/Freq.co$N))/
            sqrt(Freq.co$W1W2),
   MI=log2((Freq.co$W1W2*Freq.co$N)/(Freq.co$W1*Freq.co$W2)))
head(collocates)

   
# 4
t.score.sort <- 
  collocates[order(collocates$t.score, decreasing=T),] 
head(t.score.sort, 20)

 
# 5 
MI.sort <- 
  collocates[order(collocates$MI, decreasing=T),]     
head(MI.sort, 20)


# 6       
MI.sort <- collocates[order(collocates$MI, decreasing=T),]
head(MI.sort[MI.sort$W1W2>3,], 20)


## 7
files.list <- list.files()
Articles <- data.frame(The=vector(), A=vector())
n = 0
for (j in files.list)
{
file <- scan(file=j, what="char", quote=NULL)
n = n + 1
file <- tolower(file)
Articles[n, ] <- c(length(file[file=="the/at"]),
length(file[file=="a/at"|file=="an/at"]))
rownames(Articles)[n] <- j
}
head(Articles)
str(Articles)
summary(Articles)


## 8
par(mfrow=c(1,2))
hist(Articles$The, xlab = "the", main = "Histogram", col="lightblue")
hist(Articles$A, xlab = "a", main = "Histogram", col="darkorange")


#  9
shapiro.test(Articles$The)
shapiro.test(Articles$A)


#  10
boxplot(Articles, main="Box plot",
        col = c("lightblue", "darkorange"))


#  11
boxplot(Articles, main="Box plot",
        col = c("lightblue", "darkorange"), notch = T)


#  12
var.test(Articles$The, Articles$A)


#  13
t.test(Articles$The, Articles$A, var.equal=T)
t.test(Articles$The, Articles$A, var.equal=F)


#  14
shapiro.test(Articles$The-Articles$A)
t.test(Articles$The, Articles$A, paired=T)


#  15
files.list <- list.files()
Articles <- data.frame(Genre=vector(), 
            The=vector(), A=vector())
n = 0
for (j in files.list)
{
file <- scan(file=j, what="char", quote=NULL)
n = n + 1
file <- tolower(file)
if (grepl("cl", j)==T)
{genre <- "Mystery"}
else if (grepl("cn", j)==T)
{genre <- "Adventure"}
else
{genre <- "Romance"}
Articles[n, ] <- c(genre,
length(file[file=="the/at"])/length(file),
length(file[file=="a/at"|file=="an/at"])/length(file))
rownames(Articles)[n] <- j
}
Articles$Genre <- as.factor(Articles$Genre)
Articles$The <- as.numeric(Articles$The)
Articles$A <- as.numeric(Articles$A)
head(Articles)
summary(Articles)


# 16
par(mfrow=c(1,2))
boxplot(The~Genre, data=Articles, main = "The",
col = c("blue", "red", "orange"), notch=T)
boxplot(A~Genre, data=Articles, main = "A",
col = c("blue", "red", "orange"), notch=T)


# 17
bartlett.test(The~Genre, data=Articles)
shapiro.test(residuals(lm(The~Genre, data=Articles)))


# 18
summary(aov(The~Genre, data=Articles))
summary(aov(A~Genre, data=Articles))


# 19
TukeyHSD(aov(The~Genre, data=Articles))


# 20
files.list <- list.files()
Articles <- data.frame(Genre=vector(), 
            The=vector(), A=vector())
n = 0
for (j in files.list)
{
file <- scan(file=j, what="char", quote=NULL)
n = n + 1
file <- tolower(file)
if (grepl("cl", j)==T)
{genre <- "Mystery"}
else if (grepl("cn", j)==T)
{genre <- "Adventure"}
else
{genre <- "Romance"}
Articles[n, ] <- c(genre,
length(file[file=="the/at"]),
length(file[file=="a/at"|file=="an/at"]))
rownames(Articles)[n] <- j
}
Articles$Genre <- as.factor(Articles$Genre)
Articles$The <- as.numeric(Articles$The)
Articles$A <- as.numeric(Articles$A)
head(Articles)
summary(Articles)


# 21
Cross.Art <- xtabs(cbind(The, A)~Genre, data=Articles)
Cross.Art
str(Cross.Art)
Cross.Art <- as.data.frame.matrix(Cross.Art)
Cross.Art


# 22
chisq.test(Cross.Art)


# 23
chisq.test(Cross.Art)$expect


# 24
chisq.test(Cross.Art)$residuals
chisq.test(Cross.Art)$residuals^2


# 25
qchisq(c(0.05, 0.01, 0.001), 2, lower.tail = F)


# 26
assocplot(as.matrix(Cross.Art))
