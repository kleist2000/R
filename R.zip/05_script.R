# 1
for (i in 1:10)
{
if (i < 3)
{
cat(i, "��/�� 3���� �۴�.", '\n')
}
else if( i >= 3 & i <= 5)
{
cat(i, "��/�� 3�� 5�����̴�.", '\n')
}
else
{
cat(i, "��/�� 5���� ũ��.", '\n')
}
}



# 2
files.list <- list.files()
files.list
TEXTS <- vector()
for (i in files.list)
{
file <- scan(file=i, what="char", quote=NULL)
TEXTS <- c(TEXTS, file)
}



# 3
cat(TEXTS, file= "../Brown.txt", 
    sep="\n")



# 4
files.list <- list.files()
Mystery <- vector()
Adventure <- vector()
Romance <- vector()
for (i in files.list)
{
file <- scan(file=i, what="char", quote=NULL)
if (grepl("cl", i)==T)
{Mystery <- c(Mystery, file)}
else if (grepl("cn", i)==T)
{Adventure <- c(Adventure, file)}
else
{Romance <- c(Romance, file)}
}



# 5
dir.create("../temp")
files.list <- list.files()
for (i in files.list)
{
file <- scan(file=i, what="char", quote=NULL)
file <- tolower(file)
cat(file, file= paste("../temp/", i, ".txt", sep=""), 
    sep="\n")
}



# 6
files.list <- list.files()
Articles <- data.frame(Genre=vector(), 
            The=vector(), A=vector())
n = 0
for (j in files.list)
{
file <- scan(file=j, what="char", quote=NULL)
n = n + 1
file <- tolower(file)
if (grepl("cl", j)==T)
{genre <- "Mystery"}
else if (grepl("cn", j)==T)
{genre <- "Adventure"}
else
{genre <- "Romance"}
Articles[n, ] <- c(genre,
length(file[file=="the/at"])/length(file),
length(file[file=="a/at"|file=="an/at"])/length(file))
rownames(Articles)[n] <- j
}
head(Articles)
summary(Articles)



# 7
Articles$Genre <- as.factor(Articles$Genre)
Articles$The <- as.numeric(Articles$The)
Articles$A <- as.numeric(Articles$A)
head(Articles)
summary(Articles)


