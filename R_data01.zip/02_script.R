# 1
files.list <- list.files()
Articles <- data.frame(The=vector(), A=vector())
n = 0
for (j in files.list)
{
file <- scan(file=j, what="char", quote=NULL)
n = n + 1
file <- tolower(file)
Articles[n, ] <- 
c(length(file[file=="the/at"])/length(file),
length(file[file=="a/at"|file=="an/at"])/length(file))
rownames(Articles)[n] <- j
}


# 2
files.list <- list.files()
Articles <- data.frame(Genre=vector(), 
            The=vector(), A=vector())
n = 0
for (j in files.list)
{
file <- scan(file=j, what="char", quote=NULL)
n = n + 1
file <- tolower(file)
genre <- ifelse(grepl('cl', j), 'Mystery',
                ifelse(grepl('cn', j), 'Adventure',
                       'Romance'))
Articles[n, ] <- c(genre,
length(file[file=="the/at"])/length(file),
length(file[file=="a/at"|file=="an/at"])/length(file))
rownames(Articles)[n] <- j
}
Articles$Genre <- as.factor(Articles$Genre)
Articles$The <- as.numeric(Articles$The)
Articles$A <- as.numeric(Articles$A)


# 3
files.list <- list.files()
Articles <- data.frame(Genre=vector(), 
            The=vector(), A=vector())
n = 0
for (j in files.list)
{
file <- scan(file=j, what="char", quote=NULL)
n = n + 1
file <- tolower(file)
genre <- ifelse(grepl('cl', j), 'Mystery',
                ifelse(grepl('cn', j), 'Adventure',
                       'Romance'))
Articles[n, ] <- c(genre,
length(file[file=="the/at"]),
length(file[file=="a/at"|file=="an/at"]))
rownames(Articles)[n] <- j
}
Articles$Genre <- as.factor(Articles$Genre)
Articles$The <- as.numeric(Articles$The)
Articles$A <- as.numeric(Articles$A)

