#1
library(wordcloud)
par(mfrow=c(1,2))
wordcloud(rownames(Obama.Freq), Obama.Freq$Freq, 
scale=c(3, 0.8), min.freq=10, max.words=200, 
random.order=F, rot.per=0.4,
colors = brewer.pal(8,"Dark2"))
title(main = "OBAMA")
wordcloud(rownames(Romney.Freq), Obama.Freq$Freq, 
scale=c(3, 0.8), min.freq=10, max.words=200, 
random.order=F, rot.per=0.4,
colors = brewer.pal(8,"Dark2"))
title(main = "ROMNEY")



# 2
Obama2 <- data.frame(Word=rownames(Obama.Freq),
Freq=Obama.Freq$Freq)
Romney2 <- data.frame(Word=rownames(Romney.Freq),
Freq=Romney.Freq$Freq)
head(Obama2)
head(Romney2)



# 3
Union <- merge(Obama2, Romney2, 
               by="Word", all=T)
head(Union)
colnames(Union)[2:3] <-
c("Obama", "Romney")
head(Union)
Union[is.na(Union)] <- 0
head(Union)
Union.Freq <- data.frame(row.names=Union$Word,
Union[,2:3])
head(Union.Freq)



# 4
comparison.cloud(Union.Freq, 
scale=c(2, 0.7), max.words=300, 
random.order=F, rot.per=0.4, title.size=2,
colors = c("darkgreen", "darkorange"))



# 5
search <- "people"
which(OBAMA==search)
index <- which(OBAMA==search)
span <- vector()
for (i in index)
{
span <- c(span, (i-4):(i+4))
}
span <- span[span>0&span<=length(OBAMA)]
cooccurrence <- OBAMA[span]
cooccurrence[1:30]



# 6
Freq.span <- sort(table(cooccurrence), 
           decreasing=T)
Freq.co <- data.frame(W1=vector(),
           W2=vector(), W1W2=vector(),
           N =vector())
n <- 1
for (i in (2:length(Freq.span)))
{
Freq.co[n,] <- c(length(OBAMA[OBAMA==search]),
  length(OBAMA[OBAMA==names(Freq.span)[i]]),
  Freq.span[i], length(OBAMA))
rownames(Freq.co)[n] <- names(Freq.span)[i]
n <- n + 1                 
}
head(Freq.span)
head(names(Freq.span))
head(Freq.co)



# 7
collocates <- data.frame(Freq.co,
   t.score=(Freq.co$W1W2 - ((Freq.co$W1*Freq.co$W2)/Freq.co$N))/
           sqrt(Freq.co$W1W2),
   MI=log2((Freq.co$W1W2*Freq.co$N)/(Freq.co$W1*Freq.co$W2)))
head(collocates)
   


