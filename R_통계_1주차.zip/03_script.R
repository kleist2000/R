# 1
X <- sample(c(1, 2, 3, 4, 5, 6), size= 6, replace=T,
            prob = c(1/6, 1/6, 1/6, 1/6, 1/6, 1/6))
X
sum(X)/length(X)
Y <- sample(1:6, 6, replace=T, c(1, 1, 1, 1, 1, 1)/6)
Y
mean(Y)



# 2
for (i in 1:10)
{
cat(mean(sample(1:6, 6, replace=T, 
c(1, 1, 1, 1, 1, 1)/6)), '\n')
}



# 3
for (i in 1:10)
{
cat(mean(sample(1:6, 50, replace=T, 
c(1, 1, 1, 1, 1, 1)/6)), '\n')
}



# 4
for (i in 1:10)
{
cat(mean(sample(1:6, 100, replace=T, 
c(1, 1, 1, 1, 1, 1)/6)), '\n')
}



# 5
for (i in 1:10)
{
cat(mean(sample(1:6, 1000, replace=T, 
c(1, 1, 1, 1, 1, 1)/6)), '\n')
}




# 6
Z <- sample(1:6, 5000, replace=T, 
            c(1, 1, 1, 1, 1, 1)/6)
mean(Z)
mean.vector <- vector()     
for (i in 1:length(Z)) {    
     mean.vector <- c(mean.vector, mean(Z[1:i]))
}
head(mean.vector)
plot(1:length(mean.vector), mean.vector, 
     type="l", 
     ylab="���", xlab="ǥ��ũ��/����Ƚ��", 
     main="����� ��Ģ(law of large numbers)")
abline(h=3.5, lty=2)



# 7
par(mfrow = c(2,3))
par(mar = c(2,2,2,2))
means = vector()
for (i in 1:1000)
{
x = sample(1:6, 1, replace=T, 
           c(1, 1, 1, 1, 1, 1)/6)
means = c(means, mean(x))
}
hist(means, density=10, xlim=c(1,6), 
     main="ǥ��ũ�� = 1", xlab="")
means = vector()
for (i in 1:1000)
{
x = sample(1:6, 2, replace=T, 
           c(1, 1, 1, 1, 1, 1)/6)
means = c(means, mean(x))
}
hist(means, density=20, xlim=c(1,6), 
     main="ǥ��ũ�� = 2", xlab="")
means = vector()
for (i in 1:1000)
{
x = sample(1:6, 4, replace=T, 
           c(1, 1, 1, 1, 1, 1)/6)
means = c(means, mean(x))
}
hist(means, density=30, xlim=c(1,6), 
     main="ǥ��ũ�� = 4", xlab="")

means = vector()
for (i in 1:1000)
{
x = sample(1:6, 10, replace=T, 
           c(1, 1, 1, 1, 1, 1)/6)
means = c(means, mean(x))
}
hist(means, density=30, xlim=c(1,6), 
     main="ǥ��ũ�� = 10", xlab="")

means = vector()
for (i in 1:1000)
{
x = sample(1:6, 100, replace=T, 
           c(1, 1, 1, 1, 1, 1)/6)
means = c(means, mean(x))
}
hist(means, density=40, xlim=c(1,6), 
     main="ǥ��ũ�� = 100", xlab="")

means = vector()
for (i in 1:1000)
{
x = sample(1:6, 1000, replace=T, 
           c(1, 1, 1, 1, 1, 1)/6)
means = c(means, mean(x))
}
hist(means, density=50, xlim=c(1,6), 
     main="ǥ��ũ�� = 1000", xlab="")




# 8
x <- seq(0,10,length=10000)
head(x)
length(x)
y <- dnorm(x,mean=5, sd=1)
head(y)
length(y)
plot(x,y, type="l", ylab="Ȯ���е�", xlab="",
     main="���Ժ���", ylim=c(0, 0.5))
segments(5, 0, 5, 0.4, lty=3)
text(5, 0.42, "���(mean)", cex=0.8)
text(5, 0.45, "�߾Ӱ�(median)", cex=0.8)
text(5, 0.48, "�ֺ�(mode)", cex=0.8)




# 9
A <- c(4.26, 5.68, 7.24, 4.82, 6.95,
8.81, 8.04, 8.33, 10.84, 7.58, 9.96)
B <- c(3.1, 4.74, 6.13, 7.26, 8.14,
8.77, 9.14, 9.26, 9.13, 8.74, 8.1)
C <- c(5.39, 5.73, 6.08, 6.42, 6.77,
7.11, 7.46, 7.81, 8.15, 12.74, 8.84)
mean(A); sd(A)
mean(B); sd(B)
mean(C); sd(C)
summary(A); summary(B); summary(C)




## 10
boxplot(A, B, C, names=c("A", "B", "C"),
        xlab="ǥ��", ylab="����ġ",
        main="box plot",
        col = c("red", "yellow", "blue"))



## 11
par(mfrow=c(1, 3))
plot(1:length(A), A, ylim=c(0, max(A)),
     xlim=c(0, length(A)), main="A",
     xlab="", ylab="����ġ")
plot(1:length(B), B, ylim=c(0, max(B)),
     xlim=c(0, length(B)), main="B",
     xlab="", ylab="����ġ")
plot(1:length(C), C, ylim=c(0, max(C)),
     xlim=c(0, length(C)), main="C",
     xlab="", ylab="����ġ")

## 12
par(mfrow=c(1, 3))
hist(A)
hist(B)
hist(C)


